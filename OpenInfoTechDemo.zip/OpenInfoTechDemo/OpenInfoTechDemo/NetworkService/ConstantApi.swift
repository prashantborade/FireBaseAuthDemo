//
//  Constant.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import Foundation
import UIKit

class webConstant:NSObject
{
    
    //for Validation Message
    static let title = "OpenInfoTech"
    static let EmptyEmail = "Please Enter Your E-mail Address"
    static let CorrectEmail = "Please Enter Correct E-mail Address"
    static let EmptyPassword = "Please Enter Your Password"
    static let PasswordDoNotSpace = "Password do not accept space as Password"
    static let EmptyConfirmPassword = "Please Enter Your Confirm Password"
    static let ConfirmPasswordNotMatch = "Password and Confirm Password does not Match"
    
}
