//
//  ApiManager.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import Foundation

import UIKit
import Alamofire
import SwiftyJSON
import SVProgressHUD

let headers: HTTPHeaders = [
    "Authorization": "Info XXX",
    "Accept": "application/json",
    "Content-Type" :"application/json",
    "Content-type": "multipart/form-data"
]

class Connectivity {
    class var isConnectedToInternet:Bool {
        return NetworkReachabilityManager()!.isReachable
    }
}




