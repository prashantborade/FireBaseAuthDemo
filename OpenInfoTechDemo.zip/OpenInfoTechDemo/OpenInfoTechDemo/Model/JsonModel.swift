//
//  WeatherInfoModel.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import Foundation
import SwiftyJSON

struct JsonModel {
    
    var main:JsonMain
    var wind: JsonWind
    var clouds: JsonClouds
    var weather: [JsonWeather]
    var dt_txt:String = ""
    
    init(json:JSON) {
        
        self.main = JsonMain(jsonMain: json["main"])
        self.wind = JsonWind(jsonWind: json["wind"])
        self.clouds = JsonClouds(jsonClouds: json["clouds"])
        self.dt_txt = json["dt_txt"].stringValue
        self.weather = [JsonWeather(jsonWeather: json["weather"])]
    }
    
   
}
struct JsonWeather {
    
    var id:Int
    var main:String = ""
    var description:String = ""
    var icon:String = ""
    
    init(jsonWeather:JSON) {
        
        self.id = jsonWeather["id"].intValue
        self.main = jsonWeather["main"].stringValue
        self.description = jsonWeather["description"].stringValue
        self.icon = jsonWeather["icon"].stringValue
        
    }
}

struct JsonClouds {
    
    var all:String = ""
    
    init(jsonClouds:JSON) {
        
        self.all = jsonClouds["all"].stringValue
    }
}

struct JsonMain {
    
    var temp_min:String = ""
    var temp_max:String = ""
    var humidity:String = ""
    var pressure:String = ""
    var temp:String = ""
    
    
    
    init(jsonMain:JSON) {
        
        self.temp_min = jsonMain["temp_min"].stringValue
        self.temp_max = jsonMain["temp_max"].stringValue
        self.humidity = jsonMain["humidity"].stringValue
        self.pressure = jsonMain["pressure"].stringValue
        self.temp = jsonMain["temp"].stringValue
    }
}

struct JsonWind {
    
    var speed:Double
    var deg:Double
    
    init(jsonWind:JSON) {
        
        self.speed = jsonWind["speed"].doubleValue
        self.deg = jsonWind["deg"].doubleValue
    }
}

struct JsonCity {
    
    var name:String = ""
    var country:String = ""
    var population:String = ""
    
    init(jsonCity:JSON) {
        
        self.name = jsonCity["name"].stringValue
        self.country = jsonCity["country"].stringValue
        self.population = jsonCity["population"].stringValue
    }
}
