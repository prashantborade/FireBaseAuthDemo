//
//  SignUpVC.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import SVProgressHUD


class SignUpVC: UIViewController {
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var txtConfirmPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Sign Up"
        
    }
    
    @IBAction func btnGotoSignInClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnSignUpClicked(_ sender: Any) {
        

        if (txtEmail.text?.isEmpty)!{
            
            popupAlert(title: "OpenInfoTech", message: "Please Enter Email!!!", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if !isValidEmail(testStr: txtEmail.text!){
            
            popupAlert(title: "OpenInfoTech", message: "Please Enter Valid Email", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPassword.text?.isEmpty)!{
            
            popupAlert(title: "OpenInfoTech", message: webConstant.EmptyPassword, actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPassword.text?.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil){
            
            popupAlert(title: webConstant.title, message: webConstant.PasswordDoNotSpace, actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
        }
        else if (txtConfirmPassword.text?.isEmpty)!{
            popupAlert(title: webConstant.title, message: webConstant.EmptyConfirmPassword, actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtConfirmPassword.text?.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil){
            popupAlert(title: webConstant.title, message: webConstant.PasswordDoNotSpace, actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
        }
        else if !(txtPassword.text == txtConfirmPassword.text ) {
            popupAlert(title: webConstant.title, message: webConstant.ConfirmPasswordNotMatch, actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }
        else
        {
            
           self.createUser()
        }
    }
      
    func createUser(){
        
        if Connectivity.isConnectedToInternet {
            SVProgressHUD.show()
            SVProgressHUD.setDefaultMaskType(.clear)
            
            
            Auth.auth().createUser(withEmail: "prashantborade10@gmail.com", password: "prashant@123") {(user, error) in
                
                if user != nil {
                    
                    print("User Has SignUp")
                     UserDefaults.standard.set(true, forKey: "logged_in")
                    let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                    objAppDelegate?.gotoMainController()
                    
                }
                if error != nil {
                    
                    print(error!.localizedDescription)
                }
            }
        }
        else
        {
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
                
                self.popupAlert(title: webConstant.title, message: "Please,check your internet connection", actionTitles: ["Ok"], actions: [{ (action1) in
                    },{(action2) in
                        
                    }])
                
            }
        }
    }

}
