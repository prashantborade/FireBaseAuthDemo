//
//  SignInVC.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import UIKit
import FirebaseAuth
import SVProgressHUD



class SignInVC: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

       title = "Log In"
    }
    
    @IBAction func btnSignInClickede(_ sender: Any) {
        
        if (txtEmail.text?.isEmpty)!{
            
            popupAlert(title: "OpenInfoTech", message: "Please Enter Email!!!", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if !isValidEmail(testStr: txtEmail.text!){
            
            popupAlert(title: "OpenInfoTech", message: "Please Enter Valid Email", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPassword.text?.isEmpty)!{
            
            popupAlert(title: "OpenInfoTech", message: webConstant.EmptyPassword, actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPassword.text?.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil){
            
            popupAlert(title: webConstant.title, message: webConstant.PasswordDoNotSpace, actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
        }else
        {
        
        self.logIn()
        }
        
    }

    func logIn(){
        
        if Connectivity.isConnectedToInternet {
            SVProgressHUD.show()
            SVProgressHUD.setDefaultMaskType(.clear)
            
            
            Auth.auth().signIn(withEmail: "prashantborade10@gmail.com", password: "prashant@123") {(user, error) in
                if user != nil {
                    print("User Has Sign In")
                    UserDefaults.standard.set(true, forKey: "logged_in")
                    let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                    objAppDelegate?.gotoMainController()
                }
                if error != nil {
                    
                    print("Sign Error = \(error!.localizedDescription)")
                }
            }
        }
        else
        {
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
                
                self.popupAlert(title: webConstant.title, message: "Please,check your internet connection", actionTitles: ["Ok"], actions: [{ (action1) in
                    },{(action2) in
                        
                    }])
                
            }
        }
    }
    
    @IBAction func btnGotoSignUp(_ sender: Any) {
        
        let obj = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(obj, animated: true)
    }
    
}
