//
//  WeatherInfoListVC.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import UIKit
import SwiftyJSON
import FirebaseAuth
import SVProgressHUD


class WeatherInfoListVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var txtCityName: UITextField!
    var data = [JsonModel]()
    override func viewDidLoad() {
        super.viewDidLoad()

        txtCityName.text = "Mumbai"
        
        getData()
    }
    @IBAction func btnLogOutClicked(_ sender: Any) {
        
        popupAlert(title: "Logout", message: "Do you want to logout app ?", actionTitles: ["Yes","No"], actions: [{ (action1) in
           
            self.logOut()
            
            },{(action2) in
                
            }])

    }
    
    func logOut(){
       
        if Connectivity.isConnectedToInternet {
            SVProgressHUD.show()
            SVProgressHUD.setDefaultMaskType(.clear)
            
            let firebaseAuth = Auth.auth()
            do {
                SVProgressHUD.dismiss()
                try firebaseAuth.signOut()
                UserDefaults.standard.set(false, forKey: "logged_in")
                let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                objAppDelegate?.gotoSignInController()
            } catch let signOutError as NSError {
                print ("Error signing out: %@", signOutError)
            }
        }
        else
        {
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
                
                self.popupAlert(title: webConstant.title, message: "Please,check your internet connection", actionTitles: ["Ok"], actions: [{ (action1) in
                    },{(action2) in
                        
                    }])
                
            }
        }
        
        
    }
    @IBAction func btnRefreshClicked(_ sender: Any) {
        
        getData()
    }
   
    func getData() {
        
        if Connectivity.isConnectedToInternet {
            SVProgressHUD.show()
            SVProgressHUD.setDefaultMaskType(.clear)
            
            guard let city = txtCityName.text, !city.isEmpty else {
                popupAlert(title: "openInfoTech", message: "Please Enter City ", actionTitles: ["Ok"], actions: [{ (action1) in
                    },{(action2) in
                        
                    }])
                return
            }
            
                let url = URL(string: "https://api.openweathermap.org/data/2.5/forecast?q=\(city)&APPID=75df24af6b33491f44c749da4da0b234")
            
            print("URL = \(url)")
                URLSession.shared.dataTask(with: url!) { (data, response, error) in
                    
                    print("Error : \(error)")
                    
                    guard let data = data else { return }
                    
                    print("Data = \(data)")
                    
                    SVProgressHUD.dismiss()
                    
                    do{
                        
                        let json = try JSON(data: data)

                        //print("JSON = \(json)")
                        let results = json["list"]

                        for arr in results.arrayValue {

                            self.data.append(JsonModel(json: arr))
                            
                            print("Data = \(arr)")
                        }
                    
                        print(self.data)
                        
                        DispatchQueue.main.async {

                            self.tableView.reloadData()
                        }
                    }catch{
                        
                        print(error.localizedDescription)
                        self.popupAlert(title: webConstant.title, message: error.localizedDescription, actionTitles: ["Ok"], actions: [{ (action1) in
                            },{(action2) in
                                
                            }])
                    }
                    
                    }.resume()
        }
         else
        {
            DispatchQueue.main.async {
            SVProgressHUD.dismiss()
           
              self.popupAlert(title: webConstant.title, message: "Please,check your internet connection", actionTitles: ["Ok"], actions: [{ (action1) in
                    },{(action2) in
                        
                    }])

            }
        }
    }
}


extension WeatherInfoListVC : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:WeatherCell = self.tableView.dequeueReusableCell(withIdentifier: "WeatherCell", for: indexPath) as! WeatherCell
        
        print(data[indexPath.row].dt_txt)
        print("cell Data = \(data[indexPath.row].main)")
        cell.lblMinTemp.text = "MinTemp : \(data[indexPath.row].main.temp_min)"
        cell.lblMaxTemp.text = "MaxTemp : \(data[indexPath.row].main.temp_max)"
        cell.lbldate.text = data[indexPath.row].dt_txt
        cell.lblHumidity.text = "Humidity : \(data[indexPath.row].main.humidity)"
        cell.lblWindSpeed.text = "WindSpeed :\(data[indexPath.row].wind.speed)"
        cell.lblCloudPercentage.text = "CloudPer : \(data[indexPath.row].clouds.all)"
     
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 125.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let obj = self.storyboard?.instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
        
        obj.WeatherData = data[indexPath.row]
        obj.CityName = txtCityName.text!
        
        self.navigationController?.pushViewController(obj, animated: true)
    }
}
