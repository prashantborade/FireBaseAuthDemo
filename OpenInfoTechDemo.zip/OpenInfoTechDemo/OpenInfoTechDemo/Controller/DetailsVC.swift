//
//  GetDataVC.swift
//  OpenInfoTechDemo
//
//  Created by apple on 09/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import UIKit

class DetailsVC: UIViewController {

    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblMinTemp: UILabel!
    
    @IBOutlet weak var lblMaxTemp: UILabel!
    
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var lblCloud: UILabel!
    
    @IBOutlet weak var lblWindSpeed: UILabel!
    @IBOutlet weak var lblWindDeg: UILabel!
    
    @IBOutlet weak var lblTemp: UILabel!
    
    @IBOutlet weak var lblInfo: UILabel!
    @IBOutlet weak var lblPressure: UILabel!
    
    var WeatherData:JsonModel!
    
    var CityName:String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if WeatherData != nil {
            
        lblInfo.text = "\(CityName) Weather Information"
        lblDate.text = "Date : \(WeatherData.dt_txt)"
        lblMinTemp.text = "MinTemp : \(WeatherData.main.temp_min)"
        lblMaxTemp.text = "MaxTemp : \(WeatherData.main.temp_max)"
        lblHumidity.text = "Humidity : \(WeatherData.main.humidity)"
        lblCloud.text = "Cloud : \(WeatherData.clouds.all)"
        lblTemp.text = "Temprature : \(WeatherData.main.temp)"
        lblPressure.text = "Pressure : \(WeatherData.main.pressure)"
        lblWindSpeed.text = "WiindSpeed :\(WeatherData.wind.speed)"
        lblWindDeg.text = "WiindDeg :\(WeatherData.wind.deg)"
        }
    }
    
   
}
