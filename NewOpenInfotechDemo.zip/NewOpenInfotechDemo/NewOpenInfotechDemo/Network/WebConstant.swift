//
//  WebConstant.swift
//  NewOpenInfotechDemo
//
//  Created by apple on 16/05/19.
//  Copyright © 2019 krispindia. All rights reserved.
//

import Foundation
import  UIKit

class WebConstant:NSObject {
    
    static let title = "Open Info tech"
    static let logOutTitle = "LogOut"
    static let EmptyEmail = "Enter Email address !!!"
    static let CorrectEmail = "Please Enter correct Email !!!"
    static let EmptyPassword = "Please Enter Password"
    static let PassWordSpace = "Password do not accept space as password"
    static let EmptyConfirmPassWord = "Please Enter your confirm password"
    static let PassWordNotMatch = "Password and Confirm password does not match"
    static let EmptyCity = "Please Enter City name"
    static let checkInternet = "Please check your internet connection"
    static let logOutMessage = "Do you want to lgout app ?"
    static let LoggedIn = "logged_in"
    
    static let ApiKey = "75df24af6b33491f44c749da4da0b234"
}
